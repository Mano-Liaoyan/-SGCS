/*********************************************************************
	Rhapsody	: 9.0 
	Login		: Yanyifan Liao
	Component	: DefaultComponent 
	Configuration 	: UC_MonitorFillLevel_Simulation
	Model Element	: UC_MonitorFillLevel_Simulation
//!	Generated Date	: Sun, 16, Jul 2023  
	File Path	: DefaultComponent\UC_MonitorFillLevel_Simulation\MainDefaultComponent.h
*********************************************************************/

#ifndef MainDefaultComponent_H
#define MainDefaultComponent_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include <aom.h>
#endif
/*********************************************************************
	File Path	: DefaultComponent\UC_MonitorFillLevel_Simulation\MainDefaultComponent.h
*********************************************************************/
