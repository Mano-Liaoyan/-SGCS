/*********************************************************************
	Rhapsody	: 9.0 
	Login		: Yanyifan Liao
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Default
//!	Generated Date	: Sun, 16, Jul 2023  
	File Path	: DefaultComponent\DefaultConfig\Default.h
*********************************************************************/

#ifndef Default_H
#define Default_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include <aom.h>
//## auto_generated
class CentralServer;

//## auto_generated
class CloudPlatform;

//## auto_generated
class CommunicationSystem;

//## auto_generated
class Enviroment;

//## auto_generated
class Garbage;

//## auto_generated
class GarbageBin;

//## auto_generated
class GarbgeCollectVehicle;

//## auto_generated
class SGCS;

//## auto_generated
class SensorSystem;

//## package Default



#endif
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Default.h
*********************************************************************/
