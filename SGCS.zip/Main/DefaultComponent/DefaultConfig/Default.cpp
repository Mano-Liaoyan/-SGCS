/********************************************************************
	Rhapsody	: 9.0 
	Login		: Yanyifan Liao
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Default
//!	Generated Date	: Sun, 16, Jul 2023  
	File Path	: DefaultComponent\DefaultConfig\Default.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "Default.h"
//## auto_generated
#include "CentralServer.h"
//## auto_generated
#include "CloudPlatform.h"
//## auto_generated
#include "CommunicationSystem.h"
//## auto_generated
#include "Enviroment.h"
//## auto_generated
#include "Garbage.h"
//## auto_generated
#include "GarbageBin.h"
//## auto_generated
#include "GarbgeCollectVehicle.h"
//## auto_generated
#include "SensorSystem.h"
//## auto_generated
#include "SGCS.h"
//## package Default


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(Default, Default)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Default.cpp
*********************************************************************/
